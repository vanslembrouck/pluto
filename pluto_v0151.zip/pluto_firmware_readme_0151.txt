Firmware 1.5.1
June 12, 2022


- Configuration updates and additions

	ACCESS CONFIG MODE
	- Power off Pluto
	- Turn all knobs counterclockwise (to the left)
	- Power on Pluto (without touching the touch pads)
	- After LED startup sequence, Pluto will be in CONFIG MODE

	SAVE or CANCEL CHANGES
	- Turn CLOCK knob to exit config mode and save any changed settings
	- To cancel any changes POWER off Pluto

	ADJUST TOUCH SENSITIVITY
	- Use VOICE 1 knob to manually adjust touchpad sensitivity (CCW = more sensitive, CW = less sensitive)  
	- Test touchpads, LEDs will light up when touch is detected

	MIDI CHANNELS
	- Pluto accepts MIDI input on one channel
	- Pluto outputs MIDI from Sequence 1 and 2 to two channels
	- Switch TOGGLE 1 to set MIDI IN channel: 1, 9, 14
	- Switch TOGGLE 2 to set MIDI OUT channels: 1+2, 9+10, 14+15
	- Note: if toggle switches are not operated during CONFIG MODE, no changes will take place

	AUDIO OUT MODES
	- Turn WIDTH to change the audio out modes
	- LEDs along the top will indicate the modes:
	- ⚪️⚪️🟡⚪️⚪️ Dual mono 
	- ⚪️🟡⚪️🟡⚪️ Voice 1and 2 are panned 50% left/right
	- 🟡⚪️⚪️⚪️🟡 Voice 1and 2 are panned 100% left/right 
	- Note: effects are not panned






